﻿using System.Collections.Generic;
using System.Linq;
using ClassLibrary1;

namespace ClassLibrary2
{
    public class MyOtherClass
    {
        public IEnumerable<int> EvenAndFive(int max)
        {
            var myClass = new MyClass();

            return myClass.EvenNumbers(max).Where(i => i%5 == 0);
        }
    }
}
