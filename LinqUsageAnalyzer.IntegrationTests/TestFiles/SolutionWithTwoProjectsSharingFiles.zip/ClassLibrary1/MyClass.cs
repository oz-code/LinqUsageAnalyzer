﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class MyClass
    {
        public IEnumerable<int> EvenNumbers(int max)
        {
            return Enumerable.Range(1, 100)
                .Where(i => i%2 == 0);
        }
    }
}
